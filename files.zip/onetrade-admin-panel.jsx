import { useState, useEffect, useCallback } from "react";

const WALLET = "0x17E384Fc02A4800e1cb8644CAB9daAeA9a2861A1";
const TG_GROUP_ID = "-1003900515439";
const TG_BOT_TOKEN = "8601946674:AAGpvttyRBy7B81uU_frX8BQWk-N68lFTtQ";
const BSCSCAN_API = "https://api.bscscan.com/api";
const USDT_CONTRACT = "0x55d398326f99059fF775485246999027B3197955";

function fmt(n, dec = 2) {
  return Number(n).toLocaleString("de-DE", { minimumFractionDigits: dec, maximumFractionDigits: dec });
}
function today() {
  return new Date().toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" });
}
function todayEN() {
  return new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "long", year: "numeric" }).toUpperCase();
}
function timeNow() {
  return new Date().toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
}

async function fetchUSDTBalance(address, apiKey) {
  try {
    const key = apiKey || "YourApiKeyToken";
    const url = `${BSCSCAN_API}?module=account&action=tokenbalance&contractaddress=${USDT_CONTRACT}&address=${address}&tag=latest&apikey=${key}`;
    const res = await fetch(url);
    const data = await res.json();
    if (data.status === "1") return parseFloat(data.result) / 1e18;
    return null;
  } catch { return null; }
}

async function fetchRecentTx(address, apiKey) {
  try {
    const key = apiKey || "YourApiKeyToken";
    const url = `${BSCSCAN_API}?module=account&action=tokentx&contractaddress=${USDT_CONTRACT}&address=${address}&startblock=0&endblock=99999999&page=1&offset=10&sort=desc&apikey=${key}`;
    const res = await fetch(url);
    const data = await res.json();
    if (data.status === "1") return data.result;
    return [];
  } catch { return []; }
}

// ── Bild generieren via Claude (als Canvas HTML) ──────────────────────────────
function buildPosterHtml(pct, gainedAmount, kapital, dateStr) {
  const sign = pct >= 0 ? "+" : "";
  const pctStr = `${sign}${pct.toFixed(2)}%`;
  const gainedStr = gainedAmount > 0 ? `+${Number(gainedAmount).toLocaleString("de-DE", {minimumFractionDigits:2,maximumFractionDigits:2})} USDT` : "";
  const kapitalStr = kapital > 0 ? `${Number(kapital).toLocaleString("de-DE", {minimumFractionDigits:2,maximumFractionDigits:2})} USDT` : "";
  const barHeights = [18, 22, 20, 28, 30, 40, 52, 68, 80, 95];

  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { width:600px; height:600px; overflow:hidden; background:#050d1a; font-family:Arial,sans-serif; color:#fff; position:relative; }
  .dot-grid { position:absolute; inset:0; background-image:radial-gradient(circle, #00dca818 1px, transparent 1px); background-size:28px 28px; pointer-events:none; }
  .wrap { position:relative; z-index:1; display:flex; flex-direction:column; align-items:center; padding:22px 28px 14px; height:100%; }
  .logo { display:flex; flex-direction:column; align-items:center; margin-bottom:6px; }
  .logo-t { width:36px; height:36px; position:relative; }
  .logo-t::before { content:""; position:absolute; top:0; left:50%; transform:translateX(-50%); width:36px; height:6px; background:linear-gradient(90deg,#00dca8,#60efff); border-radius:3px; }
  .logo-t::after { content:""; position:absolute; top:6px; left:50%; transform:translateX(-50%); width:6px; height:30px; background:linear-gradient(180deg,#00dca8,#0ea5e9); border-radius:3px; }
  .logo-name { font-size:13px; font-weight:900; letter-spacing:4px; color:#fff; margin-top:8px; }
  .logo-name span { color:#00dca8; }
  .headline { font-size:22px; font-weight:900; letter-spacing:6px; color:#fff; margin:4px 0 2px; }
  .date { font-size:11px; color:#4a7090; letter-spacing:2px; margin-bottom:10px; }
  .main-box { width:100%; background:linear-gradient(135deg,#0a1a2e,#0d2040); border:1.5px solid #00dca8; border-radius:14px; padding:16px 20px 12px; position:relative; overflow:hidden; margin-bottom:12px; }
  .main-box::before { content:""; position:absolute; top:-30px; left:-30px; width:120px; height:120px; background:radial-gradient(circle,#00dca830,transparent 70%); pointer-events:none; }
  .arrow { position:absolute; right:20px; top:50%; transform:translateY(-50%); font-size:52px; opacity:0.15; }
  .result-label { font-size:10px; color:#00dca8; letter-spacing:3px; text-align:center; margin-bottom:4px; }
  .pct { font-size:68px; font-weight:900; color:#00dca8; text-align:center; line-height:1; text-shadow:0 0 30px #00dca880,0 0 60px #00dca840; letter-spacing:-2px; }
  .profit-label { font-size:10px; color:#fff; letter-spacing:3px; text-align:center; margin:6px 0 4px; opacity:0.6; }
  .tagline { font-size:11px; color:#fff; text-align:center; letter-spacing:1px; opacity:0.5; }
  .tagline span { color:#00dca8; opacity:1; }
  .stats { display:flex; width:100%; justify-content:space-between; margin-bottom:10px; }
  .stat { flex:1; display:flex; flex-direction:column; align-items:center; padding:8px 4px; border-right:1px solid #1a2d4a; }
  .stat:last-child { border-right:none; }
  .stat-icon { font-size:18px; margin-bottom:3px; }
  .stat-pct { font-size:14px; font-weight:900; color:#fff; }
  .stat-label { font-size:8px; color:#00dca8; letter-spacing:1px; text-align:center; }
  .stat-sub { font-size:8px; color:#4a7090; text-align:center; }
  .chart { width:100%; display:flex; align-items:flex-end; gap:4px; height:70px; margin-bottom:8px; padding:0 4px; }
  .bar { flex:1; border-radius:3px 3px 0 0; position:relative; }
  .curve { position:absolute; bottom:0; left:0; right:0; height:70px; pointer-events:none; }
  .quote-box { width:100%; background:#0a1525; border:1px solid #1a2d4a; border-radius:10px; padding:8px 14px; display:flex; align-items:center; gap:10px; margin-bottom:6px; }
  .quote-mark { font-size:28px; color:#00dca8; line-height:1; flex-shrink:0; font-family:Georgia,serif; }
  .quote-text { font-size:10px; color:#fff; line-height:1.5; flex:1; }
  .quote-text strong { color:#00dca8; }
  .quote-logo { font-size:9px; font-weight:900; color:#00dca8; letter-spacing:2px; text-align:right; flex-shrink:0; }
  .disclaimer { font-size:8px; color:#2a4060; letter-spacing:0.5px; text-align:center; }
  ${gainedStr ? `.gained { font-size:11px; color:#00dca870; text-align:center; margin-bottom:2px; }` : ""}
  ${kapitalStr ? `.kapital-info { font-size:9px; color:#2a5070; text-align:center; }` : ""}
</style></head>
<body>
<div class="dot-grid"></div>
<div class="wrap">
  <div class="logo">
    <div class="logo-t"></div>
    <div class="logo-name">ONE<span>TRADE</span></div>
  </div>
  <div class="headline">DAILY PERFORMANCE</div>
  <div class="date">📅 ${dateStr}</div>

  <div class="main-box">
    <div class="arrow">↗</div>
    <div class="result-label">TODAY'S RESULT</div>
    <div class="pct">${pctStr}</div>
    <div class="profit-label">· DAILY PROFIT ·</div>
    <div class="tagline">CONSISTENCY. STRATEGY. <span>SUCCESS.</span></div>
  </div>

  ${gainedStr ? `<div class="gained">💵 Ausgeschüttet: ${gainedStr}${kapitalStr ? ` &nbsp;|&nbsp; 🏦 Kapital: ${kapitalStr}` : ""}</div>` : ""}

  <div class="stats">
    <div class="stat"><div class="stat-icon">🎯</div><div class="stat-pct">100%</div><div class="stat-label">FOCUS</div><div class="stat-sub">ON YOUR GOALS</div></div>
    <div class="stat"><div class="stat-icon">📊</div><div class="stat-pct">100%</div><div class="stat-label">SYSTEM</div><div class="stat-sub">DRIVEN</div></div>
    <div class="stat"><div class="stat-icon">🛡️</div><div class="stat-pct">100%</div><div class="stat-label">RISK</div><div class="stat-sub">MANAGED</div></div>
    <div class="stat"><div class="stat-icon">👥</div><div class="stat-pct">100%</div><div class="stat-label">TEAM</div><div class="stat-sub">STRONG</div></div>
  </div>

  <div class="chart" style="position:relative;">
    ${barHeights.map((h, i) => {
      const opacity = 0.3 + (i / barHeights.length) * 0.7;
      return `<div class="bar" style="height:${h}%;background:linear-gradient(180deg,#00dca8,#0ea5e9);opacity:${opacity.toFixed(2)};box-shadow:0 0 8px #00dca840;"></div>`;
    }).join("")}
  </div>

  <div class="quote-box">
    <div class="quote-mark">"</div>
    <div class="quote-text">WE DON'T CHASE THE MARKET.<br/><strong>WE FOLLOW THE PLAN.</strong></div>
    <div class="quote-logo">ONE<br/>TRADE</div>
  </div>

  <div class="disclaimer">PAST PERFORMANCE IS NOT INDICATIVE OF FUTURE RESULTS.</div>
</div>
</body></html>`;
}


// ── Telegram: Text + Bild senden ──────────────────────────────────────────────
function buildCaption(pct, gainedAmount, kapital, currentBalance, customNote) {
  const sign = pct >= 0 ? "+" : "";
  const emoji = pct >= 0 ? "📈" : "📉";
  return `${emoji} *OneTrade – Tägliche Ausschüttung*

📅 *Datum:* ${today()} | ${timeNow()} Uhr
━━━━━━━━━━━━━━━━━
💰 *Tagesgewinn:* \`${sign}${pct.toFixed(4)}%\`
💵 *Ausgeschüttet:* \`${fmt(gainedAmount)} USDT\`
${kapital > 0 ? `🏦 *Eingesetztes Kapital:* \`${fmt(kapital)} USDT\`\n` : ""}${currentBalance > 0 ? `📊 *Wallet-Stand:* \`${fmt(currentBalance)} USDT\`\n` : ""}━━━━━━━━━━━━━━━━━
${customNote ? `📝 ${customNote}\n━━━━━━━━━━━━━━━━━\n` : ""}🤖 _Powered by OneTrade AI System_
⚠️ _Vergangene Ergebnisse sind keine Garantie für die Zukunft._`;
}

async function sendViaBackend(backendUrl, payload) {
  if (!backendUrl) return { ok: false, error: "Keine Backend-URL eingetragen! Bitte in Einstellungen eintragen." };
  const base = backendUrl.replace(/\/$/, "");
  try {
    const res = await fetch(`${base}/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const rawText = await res.text();
    let data;
    try { data = JSON.parse(rawText); } catch(e) { return { ok: false, error: "JSON Fehler: " + rawText.slice(0, 150) }; }
    if (data.ok) return { ok: true };
    return { ok: false, error: data.error || "Unbekannter Fehler" };
  } catch(e) {
    return { ok: false, error: "Fetch Fehler: " + e.message };
  }
}

async function testBackend(backendUrl) {
  if (!backendUrl) return { ok: false, error: "Keine Backend-URL eingetragen!" };
  const base = backendUrl.replace(/\/$/, "");
  try {
    const res = await fetch(`${base}/test`, { method: "POST" });
    const rawText = await res.text();
    let data;
    try { data = JSON.parse(rawText); } catch(e) { return { ok: false, error: rawText.slice(0, 150) }; }
    return data.ok ? { ok: true } : { ok: false, error: data.error };
  } catch(e) {
    return { ok: false, error: "Fetch Fehler: " + e.message };
  }
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("post");
  const [balance, setBalance] = useState(null);
  const [txList, setTxList] = useState([]);
  const [loading, setLoading] = useState(false);

  const [calcMode, setCalcMode] = useState("kapital");
  const [kapital, setKapital] = useState("");
  const [ausschuettung, setAusschuettung] = useState("");
  const [manualPrev, setManualPrev] = useState("");
  const [manualCurrent, setManualCurrent] = useState("");
  const [manualPct, setManualPct] = useState("");
  const [customNote, setCustomNote] = useState("");

  const [imageHtml, setImageHtml] = useState("");
  const [imageError, setImageError] = useState("");


  const [sendStatus, setSendStatus] = useState(null);
  const [sendLog, setSendLog] = useState("");
  const [history, setHistory] = useState([]);

  const [bscApiKey, setBscApiKey] = useState("");
  const [backendUrl, setBackendUrl] = useState(localStorage?.getItem?.("ot_backend") || "");
  const [tgToken, setTgToken] = useState(TG_BOT_TOKEN);
  const [tgGroup, setTgGroup] = useState(TG_GROUP_ID);

  // ── Berechnungen ────────────────────────────────────────────────────────────
  const kapitalVal = parseFloat(kapital) || 0;
  const ausschuettungVal = parseFloat(ausschuettung) || 0;
  const prevBal = parseFloat(manualPrev) || 0;
  const currBal = parseFloat(manualCurrent) || (balance || 0);

  const pct =
    calcMode === "manual" ? (parseFloat(manualPct) || 0)
    : calcMode === "kapital" && kapitalVal > 0 && ausschuettungVal > 0
      ? (ausschuettungVal / kapitalVal) * 100
    : calcMode === "balance" && prevBal > 0 && currBal > 0
      ? ((currBal - prevBal) / prevBal) * 100
    : 0;

  const gainedAmount =
    calcMode === "kapital" ? ausschuettungVal
    : calcMode === "balance" ? currBal - prevBal
    : 0;

  const caption = buildCaption(pct, gainedAmount, kapitalVal, currBal, customNote);
  const canGenerate = pct !== 0;

  const fetchWallet = useCallback(async () => {
    setLoading(true);
    const bal = await fetchUSDTBalance(WALLET, bscApiKey);
    const txs = await fetchRecentTx(WALLET, bscApiKey);
    setBalance(bal);
    setTxList(txs.slice(0, 8));
    setLoading(false);
  }, [bscApiKey]);

  useEffect(() => { fetchWallet(); }, [fetchWallet]);

  // ── Bild generieren ─────────────────────────────────────────────────────────
  const handleGenerateImage = () => {
    if (!canGenerate) return;
    setImageError("");
    const dateStr = todayEN();
    try {
      const html = buildPosterHtml(pct, gainedAmount, kapitalVal, dateStr);
      setImageHtml(html);
    } catch (e) {
      setImageError("Fehler: " + e.message);
    }
  };

  // ── Senden ──────────────────────────────────────────────────────────────────
  const handleSend = async () => {
    if (!canGenerate) return;
    setSendStatus("sending");
    setSendLog("📤 Sende via Backend...");

    const payload = {
      pct, gained: gainedAmount, kapital: kapitalVal,
      balance: currBal, note: customNote,
      date: today(), time: timeNow(),
    };
    const result = await sendViaBackend(backendUrl, payload);

    if (result.ok) {
      setSendStatus("ok");
      setSendLog("✅ Erfolgreich gesendet!");
      setHistory(h => [{
        date: today(), time: timeNow(), pct, gainedAmount, kapital: kapitalVal, note: customNote
      }, ...h].slice(0, 30));
      setTimeout(() => { setSendStatus(null); setSendLog(""); }, 4000);
    } else {
      setSendStatus("error");
      setSendLog("❌ " + (result.error || "Unbekannter Fehler"));
    }
  };

  // ── Styles ──────────────────────────────────────────────────────────────────
  const C = {
    bg: "#080e1a", panel: "#0d1626", border: "#1a2d4a",
    cyan: "#00dca8", cyanDim: "#00dca812", cyanBorder: "#00dca840",
    blue: "#0ea5e9", text: "#e2f0ff", muted: "#4a6080",
    red: "#f43f5e", green: "#00dca8",
  };

  const inp = { width: "100%", background: "#060d18", border: `1px solid ${C.border}`, borderRadius: 8, padding: "10px 12px", color: C.text, fontSize: 14, outline: "none", boxSizing: "border-box" };
  const card = { background: C.panel, border: `1px solid ${C.border}`, borderRadius: 12, padding: 20, marginBottom: 16 };
  const cardGlow = { ...card, border: `1px solid ${C.cyanBorder}`, boxShadow: `0 0 28px ${C.cyanDim}` };
  const label = { fontSize: 11, color: C.muted, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6, display: "block" };
  const modeBtn = (a) => ({ flex: 1, padding: "9px 6px", borderRadius: 8, border: `1px solid ${a ? C.cyanBorder : C.border}`, background: a ? C.cyanDim : "transparent", color: a ? C.cyan : C.muted, fontWeight: a ? 700 : 400, fontSize: 12, cursor: "pointer", transition: "all 0.15s" });
  const navBtn = (a) => ({ padding: "7px 16px", borderRadius: 6, border: "none", cursor: "pointer", fontSize: 13, fontWeight: a ? 600 : 400, background: a ? C.cyanDim : "transparent", color: a ? C.cyan : C.muted });
  const bigPct = { fontSize: 36, fontWeight: 900, color: pct >= 0 ? C.cyan : C.red, letterSpacing: "-1.5px", lineHeight: 1 };
  const dot = (ok) => ({ width: 8, height: 8, borderRadius: "50%", background: ok ? C.cyan : C.muted, boxShadow: ok ? `0 0 8px ${C.cyan}` : "none", display: "inline-block", marginRight: 6 });
  const badge = (ok) => ({ display: "inline-block", padding: "2px 9px", borderRadius: 20, fontSize: 11, fontWeight: 600, background: ok ? "#00dca820" : "#f43f5e20", color: ok ? C.cyan : C.red, border: `1px solid ${ok ? C.cyanBorder : "#f43f5e40"}` });

  // ── Dashboard ───────────────────────────────────────────────────────────────
  const Dashboard = () => (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div style={cardGlow}>
          <span style={label}>Wallet Balance (USDT)</span>
          {loading ? <div style={{ color: C.muted }}>Lade...</div>
            : balance !== null
              ? <><div style={{ fontSize: 22, fontWeight: 700 }}>{fmt(balance)} USDT</div>
                  <div style={{ fontSize: 12, color: C.muted, marginTop: 4 }}><span style={dot(true)} />Live BSC Wallet</div></>
              : <div style={{ fontSize: 12, color: C.muted }}>BscScan API-Key in Einstellungen eintragen</div>
          }
          <button onClick={fetchWallet} style={{ marginTop: 12, background: "transparent", border: `1px solid ${C.border}`, borderRadius: 8, padding: "7px 14px", color: C.muted, fontSize: 12, cursor: "pointer" }}>🔄 Aktualisieren</button>
        </div>
        <div style={card}>
          <span style={label}>Letzter Tagesgewinn</span>
          {history.length > 0
            ? <><div style={{ ...bigPct, fontSize: 28, color: history[0].pct >= 0 ? C.cyan : C.red }}>
                {history[0].pct >= 0 ? "+" : ""}{history[0].pct.toFixed(4)}%</div>
                <div style={{ fontSize: 12, color: C.muted, marginTop: 4 }}>{history[0].date} · +{fmt(history[0].gainedAmount)} USDT</div></>
            : <div style={{ color: C.muted, fontSize: 13 }}>Noch kein Post gesendet</div>
          }
        </div>
      </div>

      <div style={card}>
        <span style={label}>Letzte USDT-Transaktionen (BSC)</span>
        {txList.length === 0
          ? <div style={{ color: C.muted, fontSize: 13 }}>Keine Transaktionen – BscScan API-Key eintragen.</div>
          : txList.map((tx, i) => {
              const inc = tx.to.toLowerCase() === WALLET.toLowerCase();
              const amt = parseFloat(tx.value) / 1e18;
              const dt = new Date(tx.timeStamp * 1000).toLocaleString("de-DE");
              return (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: i < txList.length - 1 ? `1px solid ${C.border}` : "none", fontSize: 13 }}>
                  <div><span style={{ ...badge(inc), marginRight: 8 }}>{inc ? "Eingang" : "Ausgang"}</span><span style={{ color: C.muted }}>{dt}</span></div>
                  <div style={{ fontWeight: 600, color: inc ? C.cyan : C.red }}>{inc ? "+" : "-"}{fmt(amt)} USDT</div>
                </div>);
            })
        }
      </div>
    </div>
  );

  // ── Post Tab ────────────────────────────────────────────────────────────────
  const PostTab = () => (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>

      {/* LINKS: Eingabe */}
      <div>
        <div style={card}>
          <span style={label}>Berechnungsmethode</span>
          <div style={{ display: "flex", gap: 6, marginBottom: 16 }}>
            <button style={modeBtn(calcMode === "kapital")} onClick={() => setCalcMode("kapital")}>💰 Kapital</button>
            <button style={modeBtn(calcMode === "balance")} onClick={() => setCalcMode("balance")}>📊 Differenz</button>
            <button style={modeBtn(calcMode === "manual")} onClick={() => setCalcMode("manual")}>✏️ Manuell</button>
          </div>

          {calcMode === "kapital" && <>
            <div style={{ marginBottom: 12 }}>
              <span style={label}>Eingesetztes Kapital (USDT)</span>
              <input style={inp} placeholder="z.B. 10000" value={kapital} onChange={e => setKapital(e.target.value)} />
            </div>
            <div style={{ marginBottom: 12 }}>
              <span style={label}>Heute ausgeschüttet (USDT)</span>
              <input style={inp} placeholder="z.B. 45.00" value={ausschuettung} onChange={e => setAusschuettung(e.target.value)} />
            </div>
            {kapitalVal > 0 && ausschuettungVal > 0 &&
              <div style={{ background: C.cyanDim, border: `1px solid ${C.cyanBorder}`, borderRadius: 8, padding: "10px 14px", marginBottom: 12 }}>
                <div style={{ fontSize: 11, color: C.muted }}>Berechnet</div>
                <div style={{ fontSize: 24, fontWeight: 800, color: C.cyan }}>{pct >= 0 ? "+" : ""}{pct.toFixed(4)}%</div>
                <div style={{ fontSize: 11, color: C.muted }}>{fmt(ausschuettungVal)} ÷ {fmt(kapitalVal)} × 100</div>
              </div>
            }
          </>}

          {calcMode === "balance" && <>
            <div style={{ marginBottom: 12 }}>
              <span style={label}>Wallet-Stand gestern (USDT)</span>
              <input style={inp} placeholder="z.B. 10000.00" value={manualPrev} onChange={e => setManualPrev(e.target.value)} />
            </div>
            <div style={{ marginBottom: 12 }}>
              <span style={label}>Wallet-Stand heute (USDT)</span>
              <input style={inp} placeholder={balance ? fmt(balance) : "z.B. 10045.00"} value={manualCurrent} onChange={e => setManualCurrent(e.target.value)} />
              {balance && <button onClick={() => setManualCurrent(balance.toFixed(4))} style={{ marginTop: 6, background: "transparent", border: `1px solid ${C.border}`, borderRadius: 6, padding: "5px 10px", color: C.muted, fontSize: 11, cursor: "pointer" }}>Live-Wert übernehmen ({fmt(balance)})</button>}
            </div>
          </>}

          {calcMode === "manual" && <>
            <div style={{ marginBottom: 12 }}>
              <span style={label}>Prozentsatz manuell</span>
              <input style={inp} placeholder="z.B. 1.82" value={manualPct} onChange={e => setManualPct(e.target.value)} />
            </div>
          </>}

          <div>
            <span style={label}>Optionale Notiz</span>
            <input style={inp} placeholder="z.B. Starke Performance heute!" value={customNote} onChange={e => setCustomNote(e.target.value)} />
          </div>
        </div>

        {/* Bild generieren */}
        <div style={card}>
          <span style={label}>Post-Bild generieren (KI)</span>
          <button
            onClick={handleGenerateImage}
            disabled={!canGenerate}
            style={{ width: "100%", background: canGenerate ? `linear-gradient(135deg, #00dca8, #0ea5e9)` : C.border, border: "none", borderRadius: 8, padding: "12px 20px", color: canGenerate ? "#000" : C.muted, fontWeight: 700, fontSize: 14, cursor: canGenerate ? "pointer" : "not-allowed", marginBottom: 8 }}
          >
            🎨 OneTrade Poster erstellen
          </button>
          {!canGenerate && <div style={{ fontSize: 12, color: C.muted }}>Erst Werte eingeben um Bild zu generieren</div>}

                    {imageError && <div style={{ fontSize: 12, color: C.red, marginTop: 8, padding: "8px 12px", background: "#f43f5e10", borderRadius: 8, border: "1px solid #f43f5e30" }}>{imageError}</div>}

          {/* Bild Vorschau */}
          {imageHtml && (
            <div style={{ marginTop: 14 }}>
              <span style={label}>Vorschau</span>
              <div style={{ border: `1px solid ${C.cyanBorder}`, borderRadius: 10, overflow: "hidden", background: "#050d1a" }}>
                <iframe
                  srcDoc={imageHtml}
                  style={{ width: "100%", height: 340, border: "none", display: "block" }}
                  title="Post Vorschau"
                  sandbox="allow-scripts"
                />
              </div>
              <div style={{ fontSize: 11, color: C.muted, marginTop: 6 }}>
                ℹ️ Für Telegram wird der Text-Post gesendet. Exportiere das Bild mit Screenshot für Midjourney/DALL-E.
              </div>
            </div>
          )}
        </div>
      </div>

      {/* RECHTS: Caption + Senden */}
      <div>
        <div style={cardGlow}>
          <span style={label}>Telegram Caption Vorschau</span>
          <div style={{ background: "#060d18", border: `1px solid ${C.border}`, borderRadius: 8, padding: 14, fontFamily: "monospace", fontSize: 12, lineHeight: 1.8, color: C.text, whiteSpace: "pre-wrap", minHeight: 240 }}>
            {caption}
          </div>
        </div>

        <div style={card}>
          <span style={label}>Tagesgewinn</span>
          <div style={{ ...bigPct, marginBottom: 4 }}>
            {pct >= 0 ? "+" : ""}{pct.toFixed(4)}%
          </div>
          {gainedAmount > 0 && <div style={{ fontSize: 12, color: C.muted, marginBottom: 16 }}>+{fmt(gainedAmount)} USDT ausgeschüttet</div>}

          <button
            onClick={handleSend}
            disabled={sendStatus === "sending" || !canGenerate}
            style={{ width: "100%", background: canGenerate ? `linear-gradient(135deg, #00dca8, #0ea5e9)` : C.border, border: "none", borderRadius: 8, padding: "13px 24px", color: canGenerate ? "#000" : C.muted, fontWeight: 700, fontSize: 14, cursor: canGenerate ? "pointer" : "not-allowed", marginBottom: 10 }}
          >
            {sendStatus === "sending" ? "⏳ Sende..." : sendStatus === "ok" ? "✅ Gesendet!" : sendStatus === "error" ? "❌ Fehler" : "📤 Jetzt an Telegram senden"}
          </button>

          {sendLog && (
            <div style={{ background: "#060d18", border: `1px solid ${sendStatus === "ok" ? C.cyanBorder : sendStatus === "error" ? "#f43f5e40" : C.border}`, borderRadius: 8, padding: "10px 14px", fontSize: 12, color: sendStatus === "ok" ? C.cyan : sendStatus === "error" ? C.red : C.muted, fontFamily: "monospace", marginTop: 8, wordBreak: "break-word" }}>
              {sendLog}
            </div>
          )}

          {/* Telegram Test */}
          <button
            onClick={async () => {
              setSendLog("🔧 Teste Backend-Verbindung...");
              setSendStatus("sending");
              const r = await testBackend(backendUrl);
              if (r.ok) { setSendStatus("ok"); setSendLog("✅ Backend & Bot funktionieren!"); }
              else { setSendStatus("error"); setSendLog("❌ " + (r.error || "Fehler")); }
            }}
            style={{ width: "100%", marginTop: 8, background: "transparent", border: `1px solid ${C.border}`, borderRadius: 8, padding: "9px 16px", color: C.muted, fontSize: 12, cursor: "pointer" }}
          >
            🔧 Backend & Bot testen
          </button>

          <div style={{ borderTop: `1px solid ${C.border}`, marginTop: 14, paddingTop: 14, fontSize: 12, color: C.muted, lineHeight: 1.8 }}>
            <strong style={{ color: C.text }}>Bot:</strong> OneTrade Bot<br />
            <strong style={{ color: C.text }}>Gruppe:</strong> {tgGroup}<br />
            <strong style={{ color: C.text }}>Token:</strong> {tgToken.slice(0, 10)}...<br />
            <div style={{ marginTop: 6, padding: "6px 10px", background: "#060d18", borderRadius: 6, fontSize: 11 }}>
              ⚠️ Bot muss <strong style={{ color: C.cyan }}>Admin</strong> in der Telegram-Gruppe sein!
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // ── Verlauf ─────────────────────────────────────────────────────────────────
  const HistoryTab = () => (
    <div style={card}>
      <span style={label}>Gesendete Posts</span>
      {history.length === 0
        ? <div style={{ color: C.muted, fontSize: 13 }}>Noch keine Posts gesendet.</div>
        : history.map((h, i) => (
          <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: i < history.length - 1 ? `1px solid ${C.border}` : "none" }}>
            <div>
              <div style={{ fontWeight: 600 }}>{h.date} · {h.time} Uhr</div>
              <div style={{ fontSize: 12, color: C.muted }}>+{fmt(h.gainedAmount)} USDT{h.kapital > 0 ? ` · Kapital: ${fmt(h.kapital)} USDT` : ""}{h.note ? ` · ${h.note}` : ""}</div>
            </div>
            <div style={{ fontSize: 20, fontWeight: 800, color: h.pct >= 0 ? C.cyan : C.red }}>{h.pct >= 0 ? "+" : ""}{h.pct.toFixed(4)}%</div>
          </div>
        ))
      }
    </div>
  );

  // ── Einstellungen ────────────────────────────────────────────────────────────
  const SettingsTab = () => (
    <div>
      <div style={card}>
        <span style={label}>API & Bot Konfiguration</span>
        <div style={{ marginBottom: 14, padding: "12px 14px", background: "#00dca810", border: "1px solid #00dca840", borderRadius: 10 }}>
          <span style={{ ...label, color: C.cyan }}>🔗 Backend URL (Render.com)</span>
          <input
            style={{ ...inp, border: backendUrl ? "1px solid #00dca840" : "1px solid #f43f5e40" }}
            placeholder="https://onetrade-bot.onrender.com"
            value={backendUrl}
            onChange={e => {
              setBackendUrl(e.target.value);
              try { localStorage.setItem("ot_backend", e.target.value); } catch(err) {}
            }}
          />
          <div style={{ fontSize: 11, color: C.muted, marginTop: 4 }}>
            {backendUrl ? "✅ URL eingetragen" : "⚠️ Pflichtfeld – ohne Backend kann nicht gesendet werden!"}
          </div>
        </div>

        <div style={{ marginBottom: 14 }}>
          <span style={label}>BscScan API-Key (für Live-Wallet)</span>
          <input style={inp} placeholder="Kostenlos auf bscscan.com → API Keys" value={bscApiKey} onChange={e => setBscApiKey(e.target.value)} />
        </div>
        <div style={{ marginBottom: 14 }}>
          <span style={label}>Telegram Bot Token</span>
          <input style={inp} value={tgToken} onChange={e => setTgToken(e.target.value)} />
        </div>
        <div style={{ marginBottom: 14 }}>
          <span style={label}>Telegram Gruppen-ID</span>
          <input style={inp} value={tgGroup} onChange={e => setTgGroup(e.target.value)} />
        </div>
        <button onClick={fetchWallet} style={{ background: C.cyanDim, border: `1px solid ${C.cyanBorder}`, borderRadius: 8, padding: "10px 20px", color: C.cyan, fontWeight: 600, fontSize: 13, cursor: "pointer" }}>🔄 Wallet neu laden</button>
      </div>

      <div style={card}>
        <span style={label}>Workflow: Wie du täglich postest</span>
        <div style={{ fontSize: 13, color: C.muted, lineHeight: 2 }}>
          <div>1️⃣ Tab <strong style={{ color: C.text }}>"Post erstellen"</strong> öffnen</div>
          <div>2️⃣ Kapital + heutige Ausschüttung eingeben</div>
          <div>3️⃣ <strong style={{ color: C.cyan }}>🎨 Poster erstellen</strong> → Vorschau prüfen</div>
          <div>4️⃣ <strong style={{ color: C.cyan }}>📤 An Telegram senden</strong></div>
          <div>5️⃣ Optional: Poster screenshotten → als Bild manuell posten</div>
        </div>
      </div>
    </div>
  );

  // ── Render ───────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight: "100vh", background: `radial-gradient(ellipse at 20% 0%, #00dca808 0%, transparent 60%), #080e1a`, color: C.text, fontFamily: "'Inter','Segoe UI',sans-serif", fontSize: 14 }}>
      {/* Header */}
      <div style={{ borderBottom: `1px solid ${C.border}`, padding: "16px 28px", display: "flex", alignItems: "center", gap: 14, background: C.panel }}>
        <div style={{ width: 38, height: 38, background: `linear-gradient(135deg,${C.cyan},${C.blue})`, borderRadius: 9, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900, fontSize: 16, color: "#000" }}>OT</div>
        <div>
          <div style={{ fontSize: 17, fontWeight: 700 }}>OneTrade · Daily Profit System</div>
          <div style={{ fontSize: 12, color: C.muted }}>Automatisiertes Telegram-Posting · BSC Wallet Tracker</div>
        </div>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
          <span style={dot(true)} /><span style={{ fontSize: 12, color: C.muted }}>Live</span>
        </div>
      </div>

      {/* Nav */}
      <div style={{ display: "flex", gap: 2, padding: "10px 28px", borderBottom: `1px solid ${C.border}`, background: C.panel }}>
        {[["dashboard","📊 Dashboard"],["post","✍️ Post erstellen"],["history","📋 Verlauf"],["settings","⚙️ Einstellungen"]].map(([k,l]) => (
          <button key={k} style={navBtn(tab === k)} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>

      {/* Content */}
      <div style={{ padding: "24px 28px", maxWidth: 980, margin: "0 auto" }}>
        {tab === "dashboard" && <Dashboard />}
        {tab === "post" && <PostTab />}
        {tab === "history" && <HistoryTab />}
        {tab === "settings" && <SettingsTab />}
      </div>
    </div>
  );
}
